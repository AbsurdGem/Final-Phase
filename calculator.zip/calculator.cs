using System;
using System.Collections.Generic;
using System.Linq;

namespace CalculatorApp
{
    public class Calculator
    {
        private List<double> memory = new List<double>();

        public void Start()
        {
            string input;
            do
            {
                ShowMenu();
                input = Console.ReadLine().Trim().ToLower();

                switch (input)
                {
                    case "1":
                        PerformOperation("add");
                        break;
                    case "2":
                        PerformOperation("subtract");
                        break;
                    case "3":
                        PerformOperation("multiply");
                        break;
                    case "4":
                        PerformOperation("divide");
                        break;
                    case "5":
                        StoreToMemory();
                        break;
                    case "6":
                        RecallMemory();
                        break;
                    case "q":
                        Console.WriteLine("Thank you for using the calculator. Goodbye!");
                        break;
                    default:
                        Console.WriteLine("Invalid option. Try again.");
                        break;
                }

            } while (input != "q");
        }

        private void ShowMenu()
        {
            Console.WriteLine("\nSelect an option:");
            Console.WriteLine("1) Add");
            Console.WriteLine("2) Subtract");
            Console.WriteLine("3) Multiply");
            Console.WriteLine("4) Divide");
            Console.WriteLine("5) Store result to memory");
            Console.WriteLine("6) Recall memory");
            Console.WriteLine("Q) Quit");
            Console.Write("Choice: ");
        }

        private void PerformOperation(string operation)
        {
            Console.WriteLine($"\nEnter numbers separated by spaces for {operation}:");
            string[] input = Console.ReadLine().Split();

            try
            {
                List<double> numbers = input.Select(num => double.Parse(num)).ToList();

                if (numbers.Count < 2)
                {
                    Console.WriteLine("Please enter at least two numbers.");
                    return;
                }

                double result = numbers[0];
                for (int i = 1; i < numbers.Count; i++)
                {
                    switch (operation)
                    {
                        case "add":
                            result += numbers[i];
                            break;
                        case "subtract":
                            result -= numbers[i];
                            break;
                        case "multiply":
                            result *= numbers[i];
                            break;
                        case "divide":
                            if (numbers[i] == 0)
                            {
                                Console.WriteLine("Division by zero detected. Operation skipped.");
                                return;
                            }
                            result /= numbers[i];
                            break;
                    }
                }

                Console.WriteLine($"Result: {result:F2}");
                lastResult = result;
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid input. Please enter numeric values.");
            }
        }

        private double lastResult;

        private void StoreToMemory()
        {
            if (memory.Count >= 10)
            {
                memory.RemoveAt(0);
            }
            memory.Add(lastResult);
            Console.WriteLine($"Stored {lastResult:F2} to memory.");
        }

        private void RecallMemory()
        {
            Console.WriteLine("Memory Contents:");
            if (memory.Count == 0)
            {
                Console.WriteLine("Memory is empty.");
                return;
            }

            for (int i = 0; i < memory.Count; i++)
            {
                Console.WriteLine($"[{i}] {memory[i]:F2}");
            }
        }
    }
}
