﻿using System;

namespace CalculatorApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Phase 5: Final Calculator Project ===");
            Console.WriteLine("Developer: [Morgan Moore]\n");

            Calculator calc = new Calculator();
            calc.Start();
        }
    }
}
